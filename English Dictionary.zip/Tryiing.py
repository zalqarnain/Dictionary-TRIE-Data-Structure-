import bs4
import requests
import os
from urllib.request import urlretrieve
from urllib.request import urlopen as ureq
from bs4 import BeautifulSoup as soup
ibrahim = 'a'
mymwebsite=('https://www.dictionary.com')
ucm=ureq(mymwebsite)
pagereadm=ucm.read()
ucm.close()
pagem=soup(pagereadm,"html.parser")
while(ibrahim <= 'z'):
    popo=pagem.find("li",{"class":"css-3w1ibo e1wvt9ur6"})
    dfs = popo.find("span",{"data-page"})
    x=1
    while(x  <= dfs):
        data=open("url_tryiing.txt","a")

        mywebsite=('https://www.dictionary.com/list/f/' + str(x))
        uc=ureq(mywebsite)
        pageread=uc.read()
        uc.close()
        page=soup(pageread,"html.parser")
        p=page.find("ul",{"class":"css-1y59cbu e1j8zk4s0"})
        trs=p.findAll("li")
        #trs=mytable.findChildren('tr')
        # print("asad")
        #print(trs)
        # print(len(trs))
        i=0
        while(i<len(trs)):
            ref=trs[i].a["href"]
            data.write(ref+"\n")
            print(ref)
            print("\n")
            i=i+1
        x = x+1
    ibrahim = ibrahim+1