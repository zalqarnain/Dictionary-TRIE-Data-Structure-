#include<iostream>
#include<string>
#include<fstream>
using namespace std;
struct node
{
	char c;
	node **children;
	string meaning;
	node(char c = 0)
	{
		this->c = c;
		children = new node*[96];
	}
};
class Trie_structure
{
private:
	node *trie = new node;
	string save_relative_words;
	int count;
public:
	Trie_structure()
	{
		int i = 0;
		while (i < 96)
		{
			trie->children[i] = NULL;
			i++;
		}
		trie->children[95] = new node;
		trie->children[95]->meaning = "\0";
		save_relative_words = "";
		count = 0;
	}
	void heading()
	{
		system("CLS");
		cout << endl;
		cout << "\t\t     *******************************************************************" << endl;
		cout << "\t\t    |  ___  __   __,  ___ ___2  ___ ___ ___2  __  _  _  __   __  _   _\t|" << endl;
		cout << "\t\t    |  |__ |__| |__    |   |   |     |   |   |  | |\\ | |__| |__!  \\_/\t|" << endl;
		cout << "\t\t    |  !   !  ! .__!   !  _!_  !___  !  _!_  !__! | \\| !  ! !  \\   |\t|" << endl;
		cout << "\t\t    |\t\t\t\t\t\t\t\t\t|" << endl;
		cout << "\t\t     *******************************************************************" << endl << endl;
	}
	void insertion(string dictionary_word, string dictionary_word_meaning)
	{
		int size = dictionary_word.length();
		int i = 0;
		node *temp = trie;
		while (i < size)
		{
			if (temp->children[dictionary_word[i] - 32] == NULL)
			{
				temp->children[dictionary_word[i] - 32] = new node(dictionary_word[i]);
				temp = temp->children[dictionary_word[i] - 32];
				int k = 0;
				while (k < 96)
				{
					temp->children[k] = NULL;
					k++;
				}
				temp->children[95] = new node(dictionary_word[i]);
				temp->children[95]->meaning = "\0";
			}
			else
			{
				temp = temp->children[dictionary_word[i] - 32];
			}
			i++;
		}
		temp->children[95]->meaning = dictionary_word_meaning;
	}
	void trie_imply()
	{
		ifstream infile;
		char abc;
		abc = 'A';
		while (abc <= 'Z')
		{
			string def = "";
			def = def + "meaning_" + abc;
			def = def + ".txt";
			infile.open(def);
			string dictionary_meaning;
			while (!infile.eof())
			{
				string temp = "";
				dictionary_meaning = "";
				getline(infile, temp);
				string dictionary_word = temp;
				cout << dictionary_word << ":" << endl;
				while (temp != ";;;")
				{
					temp = "";
					getline(infile, temp);
					if (temp != ";;;")
					{
						temp = '\n' + temp;
						dictionary_meaning = dictionary_meaning + temp;
					}
				}
				insertion(dictionary_word, dictionary_meaning);
			}
			abc = abc + 1;
			infile.close();
		}
	}
	node *searching(string word, node *parent, node *temp, int i = 0)
	{
		if (temp != NULL)
		{
			if (i < word.length())
			{

				string temporary;
				if (i == word.length() - 1)
				{
					if (temp->children[95]->meaning != "\0")
					{
						temporary = word;
						temporary[temporary.length() - 1] = '\0';
						int q = 1;
						while (q < temporary.length())
						{
							if ((temporary[q] > 64 && temporary[q] <= 90) && (temporary[q - 1] > 96 && temporary[q - 1] <= 122))
							{
								temporary[q] = temporary[q] + 32;
							}
							q++;
						}
						save_relative_words = save_relative_words + "\t\t\t\t\t" + temporary + '\n';
						count++;
					}
					int u = 0;
					while (u < 95)
					{
						if (temp->children[u] != NULL)
						{
							if (temp->children[u]->children[95]->meaning != "\0")
							{
								temporary = word;
								temporary[temporary.length() - 1] = u + 32;
								temporary[temporary.length()] = '\0';
								int q = 1;
								while (q < temporary.length())
								{
									if ((temporary[q] > 64 && temporary[q] <= 90) &&(temporary[q-1] > 96 && temporary[q-1] <= 122))
									{
										temporary[q] = temporary[q] + 32;
									}
									q++;
								}
								save_relative_words = save_relative_words + "\t\t\t\t\t" + temporary + '\n';
								count++;
							}
						}
						u++;
					}
				}
				if ((word[i] > 96 && word[i] <= 122) && (temp->children[word[i] - 32] != NULL || temp->children[(word[i] - 32) - 32] != NULL))
				{
					node *capital = NULL, *small = NULL;
					if (temp->children[word[i] - 32] != NULL)
					{
						small = searching(word, temp, temp->children[word[i] - 32], i + 1);
					}
					if (temp->children[(word[i] - 32) - 32] != NULL)
					{
						capital = searching(word, temp, temp->children[(word[i] - 32) - 32], i + 1);
					}
					if (small == NULL && capital == NULL)
					{
						return NULL;
					}
					else if (small != NULL)
					{
						return small;
					}
					else
					{
						return capital;
					}
				}
				else if ((word[i] > 64 && word[i] <= 90) && (temp->children[word[i] - 32] != NULL || temp->children[(word[i] - 32) + 32] != NULL))
				{
					node *capital = NULL, *small = NULL;
					if (temp->children[word[i] - 32] != NULL)
					{
						capital = searching(word, temp, temp->children[word[i] - 32], i + 1);
					}
					if (temp->children[(word[i] - 32) + 32] != NULL)
					{
						small = searching(word, temp, temp->children[(word[i] - 32) + 32],i + 1);
					}
					if (small == NULL && capital == NULL)
					{
						return NULL;
					}
					else if (small != NULL)
					{
						return small;
					}
					else
					{
						return capital;
					}
				}
				else if (temp->children[word[i] - 32] != NULL)
				{
					node *other = searching(word, temp, temp->children[word[i] - 32], i + 1);
					return other;
				}
				else
				{
					return NULL;
				}
			}
			else
			{
				if (temp->children[95]->meaning != "\0")
				{
					return temp;
				}
				else
				{
					return NULL;
				}
			}
		}
	}
	void search(string word)
	{
		node *point;
		if ((point = searching(word,trie,trie)) != NULL)
		{
			if (point->children[95]->meaning != "\0")
			{
				details_print();
				cout << point->children[95]->meaning;
				count = 0;
				save_relative_words = "\0";
			}
		}
		else
		{
			indication_not_found();
			if (count > 0)
			{
				cout << "\t\t\t\t\t-------------------" << endl;
				cout << "\t\t\t\t\tSearch instead for:" << endl;
				cout << "\t\t\t\t\t-------------------" << endl;
				cout << save_relative_words;
				count = 0;
				save_relative_words = "\0";
			}
		}
	}
	void indication_not_found()
	{
		cout << "\t\t\t\t\t----------------------------" << endl;
		cout << "\t\t\t\t\tNot exactly match word found" << endl;
		cout << "\t\t\t\t\t----------------------------" << endl;
		cout << endl << endl;
	}
	void details_print()
	{
		cout << "     ________________________" << endl;
		cout << "   /|\t\t\t    |\\" << endl;
		cout << "  < |\tDETAILS:\t    | >" << endl;
		cout << "   \\|_______________________|/" << endl;
	}
};
int main()
{
	Trie_structure dicto;
	dicto.heading();
	dicto.trie_imply();
	dicto.heading();
	string search_word;
	int c = 1;
	while (c == 1)
	{
		dicto.heading();
		cout << "\t\t\t\t\t----------------------------" << endl;
		cout << "\t\t\t\t\tENTER WORD TO SEARCH: ";
		getline(cin, search_word);
		dicto.search(search_word);
		cout << "\t\t\t\t\t----------------------------" << endl;
		cout << "\t\t\t\t\tENTER 1 TO SEARCH ANOTHER WORD: " << endl << "\t\t\t\t\t\t   OR " << endl << "\t\t\t\t\tPRESS ANY OTHER KEY TO EXIT" << endl << "\t\t\t\t\t----------------------------" << endl << "\t\t\t\t\t\t   ";
		cin >> c;
		search_word = "\0";
		cin.ignore();
	}
}