import requests
# import html5lib
from bs4 import BeautifulSoup
from urllib.request import urlopen

url = "https://www.lexico.com/definition/python"
r=requests.get(url)
htmlContent=r.content
# htmlContent=htmlContent.decode("utf-8")#.split()
# print(htmlContent)


soup=BeautifulSoup(htmlContent,'html.parser')
tag = soup.find_all("span","ind")
a=1
tat = href="/definition/a-">a-</a>
for i in tag:
    print (a,".",i.text)
    a=a+1
# # print(soup.prettify)
# title=soup.title
# # print(type(title))


# words=soup.words
# # print(type(words))

# # words=soup.findAll()
# url = "https://www.vocabulary.com/dictionary"
# page = urlopen(url)
# soup=BeautifulSoup(page,'html.parser')
# data=soup.findAll('div')
# print(data)